import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SlideShow extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Panels for slideshow images, description text, and navigation buttons
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private JPanel bottomPane;

	// CardLayout allows the slideshow and text to switch together
	private CardLayout card;
	private CardLayout cardText;

	// Navigation buttons
	private JButton btnPrev;
	private JButton btnNext;

	// Labels for image and text
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		// Initialize layout managers
		card = new CardLayout();
		cardText = new CardLayout();

		// Initialize panels
		slidePane = new JPanel();
		textPane = new JPanel();
		buttonPane = new JPanel();
		bottomPane = new JPanel(new BorderLayout());

		// Initialize buttons and labels
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		// Frame setup
		setSize(800, 600);
		setLocationRelativeTo(null);

		// Updated window title to reflect new wellness requirement
		setTitle("Top 5 Detox/Wellness Destinations SlideShow");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout());

		// Slide panel uses CardLayout for image slideshow
		slidePane.setLayout(card);

		// Text panel uses CardLayout so each slide has matching text
		textPane.setLayout(cardText);
		textPane.setBackground(Color.WHITE);

		// Add each slide image and matching text description
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();

			// Updated images and text now support detox/wellness travel theme
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));

			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		// Add slideshow to center of frame
		getContentPane().add(slidePane, BorderLayout.CENTER);

		// Button panel setup
		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		// Combine text and buttons so both show at the bottom
		bottomPane.add(textPane, BorderLayout.CENTER);
		bottomPane.add(buttonPane, BorderLayout.SOUTH);

		getContentPane().add(bottomPane, BorderLayout.SOUTH);
	}

	/**
	 * Previous Button Functionality
	 * Moves slideshow and description text to previous card.
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}

	/**
	 * Next Button Functionality
	 * Moves slideshow and description text to next card.
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * Method to get the images for each wellness destination.
	 * You can keep the same image file names if those are the only files provided.
	 */
	private String getResizeIcon(int i) {
		String image = "";
		if (i == 1) {
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/TestImage1.jpg") + "'></body></html>";
		} else if (i == 2) {
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/TestImage2.jpg") + "'></body></html>";
		} else if (i == 3) {
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/TestImage3.jpg") + "'></body></html>";
		} else if (i == 4) {
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/TestImage4.jpg") + "'></body></html>";
		} else if (i == 5) {
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/TestImage5.jpg") + "'></body></html>";
		}
		return image;
	}

	/**
	 * Method to get updated text values for detox/wellness destinations.
	 * Content was revised based on Product Owner's new requirements.
	 */
	private String getTextDescription(int i) {
		String text = "";
		if (i == 1) {
			text = "<html><body><font size='5'>#1 Sedona Wellness Retreat</font><br>"
					+ "Relax with spa treatments, guided meditation, and scenic desert healing experiences."
					+ "</body></html>";
		} else if (i == 2) {
			text = "<html><body><font size='5'>#2 Bali Detox Escape</font><br>"
					+ "Recharge with yoga sessions, healthy meals, and peaceful tropical surroundings."
					+ "</body></html>";
		} else if (i == 3) {
			text = "<html><body><font size='5'>#3 Costa Rica Nature Renewal</font><br>"
					+ "Enjoy eco-luxury lodging, wellness activities, and a full digital detox experience."
					+ "</body></html>";
		} else if (i == 4) {
			text = "<html><body><font size='5'>#4 Arizona Spa and Cleanse Getaway</font><br>"
					+ "Focus on rest, nutrition, and personal wellness through guided detox programs."
					+ "</body></html>";
		} else if (i == 5) {
			text = "<html><body><font size='5'>#5 Thailand Yoga Retreat</font><br>"
					+ "Experience mindfulness, beachfront yoga, and holistic wellness treatments."
					+ "</body></html>";
		}
		return text;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}